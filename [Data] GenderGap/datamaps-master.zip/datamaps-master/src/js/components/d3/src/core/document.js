var d3_document = document,
    d3_documentElement = d3_document.documentElement,
    d3_window = window;
