d3 = (function(){
  var d3 = {version: "3.2.2"}; // semver
