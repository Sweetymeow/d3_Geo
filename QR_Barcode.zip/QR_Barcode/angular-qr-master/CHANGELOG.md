## 0.2.0 (2014-06-22)


#### Bug Fixes

* binding attributes ([eb3c89ea](git://github.com/janantala/angular-qr.git/commit/eb3c89ea1c0882489e7ad2a62fc780b6ec30a4bd))
* **gulp-changelog:** module no longer available ([7ddd57fa](git://github.com/janantala/angular-qr.git/commit/7ddd57fa17b4b5ca0c2b172780c85a1053345362))


#### Features

* render  qr code into img element ([10ea4681](git://github.com/janantala/angular-qr.git/commit/10ea46817854c4080077d4a2bafb010430f549d3))
* **build:**
  * use changelog directly ([8b9287c0](git://github.com/janantala/angular-qr.git/commit/8b9287c0f8f2c1edb6ddf1880ac7d8d582706c7c))


<a name="v0.1.4"></a>
### v0.1.4 (2013-12-18)


#### Features

* **bower:** require angular 1.2.x version ([b5458a21](https://github.com/janantala/angular-qr/commit/b5458a2156cb00d1ea9e4520db17a07c1079b8ba))

<a name="v0.1.3"></a>
### v0.1.3 (2013-11-14)


#### Bug Fixes

* **is8bit:** max 8bit character has code 255 not 256 ([deebe0eb](https://github.com/janantala/angular-qr/commit/deebe0eb2eb353a52e023a37e1478e75f7b7221a))


<a name="v0.1.2"></a>
### v0.1.2 (2013-11-13)


#### Features

* **conventional-changelog:** add changelog support ([8dafd515](https://github.com/janantala/angular-qr/commit/8dafd515f0bf361366047838b024c22d767bae0b))

