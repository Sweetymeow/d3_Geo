The main module is a program that creates a widget.  When a user clicks on
the widget, the program loads the mozilla.org website in a new tab.
