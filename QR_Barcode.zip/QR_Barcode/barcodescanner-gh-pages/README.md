barcodescanner
==============

A webcam barcode reader


This is an attempt to solve this issue
https://github.com/jhuckaby/webcamjs/issues/9

using jhuckaby's and eddiela's code

Live demo:

http://tonylampada.github.io/barcodescanner/