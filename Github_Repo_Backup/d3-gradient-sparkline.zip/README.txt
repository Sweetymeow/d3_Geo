A Pen created at CodePen.io. You can find this one at http://codepen.io/acondiff/pen/LhqKv.

 A graph that uses colors and gradients to signify lower values on a D3 line graph.